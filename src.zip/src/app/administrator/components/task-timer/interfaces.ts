export interface ITimerChange {
  task_id: string;
  start_time: number;
}
