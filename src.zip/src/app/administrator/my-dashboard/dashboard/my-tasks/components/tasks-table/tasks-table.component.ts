import {ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnInit} from '@angular/core';
import {log_error} from "@shared/utils";
import {AuthService} from "@services/auth.service";
import {IMyTask} from "@interfaces/my-tasks";
import {HomePageApiService} from "@api/home-page-api.service";
import {HomepageService} from "../../../../homepage-service.service";
import {takeUntilDestroyed} from "@angular/core/rxjs-interop";
import {IProjectTask} from "@interfaces/api-models/project-tasks-view-model";
import {merge} from "rxjs";
import {TaskViewService} from "@admin/components/task-view/task-view.service";
import {ILocalSession} from "@interfaces/api-models/local-session";
import {ProjectsService} from "../../../../../projects/projects.service";
import {IProjectViewModel} from "@interfaces/api-models/project-view-model";
import {DRAWER_ANIMATION_INTERVAL} from "@shared/constants";
import {IProject} from "@interfaces/project";

@Component({
  selector: 'worklenz-tasks-table',
  templateUrl: './tasks-table.component.html',
  styleUrls: ['./tasks-table.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TasksTableComponent implements OnInit {
  private session: ILocalSession | null = null;
  protected selectedTask: IProjectTask | null = null;
  @Input() filterValue: number = 0;
  projects: IProject[] = [];

  loading = false;
  showTaskModal = false;

  constructor(
    private readonly auth: AuthService,
    private readonly cdr: ChangeDetectorRef,
    private readonly homePageApi: HomePageApiService,
    private readonly projectService: ProjectsService,
    private readonly taskViewService: TaskViewService,
    public readonly homePageService: HomepageService
  ) {

    this.homePageService.newTaskReceived
      .pipe(takeUntilDestroyed())
      .subscribe(task => {
        this.handleNewTaskReceived(task);
      });

    this.taskViewService.onViewBackFrom
      .pipe(takeUntilDestroyed())
      .subscribe(task => {
        const task_: IProjectTask = {
          id: task.parent_task_id,
          project_id: task.project_id,
        }
        this.handleTaskSelectFromView(task_);
      });

    this.taskViewService.onSelectSubTask
      .pipe(takeUntilDestroyed())
      .subscribe(task => {
        this.handleTaskSelectFromView(task);
      });

    this.homePageService.onGetTasks
      .pipe(takeUntilDestroyed())
      .subscribe(config => {
        this.getTasks(true);
      })

    this.homePageService.onGetTasksWithoutLoading
      .pipe(takeUntilDestroyed())
      .subscribe(config => {
        this.getTasks(false);
      })

    merge(
      this.taskViewService.onAssigneesChange,
      this.taskViewService.onEndDateChange,
      this.taskViewService.onStatusChange
    )
      .pipe(takeUntilDestroyed())
      .subscribe(() => {
        void this.getTasks(false);
      });

    this.taskViewService.onDelete
      .pipe(takeUntilDestroyed())
      .subscribe(value => {
        if (value.parent_task_id) {
          const task_: IProjectTask = {
            id: value.parent_task_id,
            project_id: value.project_id as string
          }
          this.handleTaskSelectFromView(task_);
        }
        void this.getTasks(false);
      });
  }

  ngOnInit() {
    this.session = this.auth.getCurrentSession();
    this.getProjects();
    this.getTasks(true);
  //   this.projects = [
  //     {
  //         "id": "19460e37-ae4f-4504-acb8-40945b4a517f",
  //         "name": "silcontech",
  //         "color_code": "#3b7ad4"
  //     },
  //     {
  //         "id": "b77e3846-d281-47f0-b2fd-171fd1045526",
  //         "name": "Food App",
  //         "color_code": "#3b7ad4"
  //     },
  //     {
  //         "id": "d2025708-bf28-432b-9331-a85c4a7434aa",
  //         "name": "P&L",
  //         "color_code": "#3b7ad4"
  //     },
  //     {
  //         "id": "068918ed-76c3-4643-812e-09a987f2da7e",
  //         "name": "sample project",
  //         "color_code": "#3b7ad4"
  //     },
  //     {
  //         "id": "0e6f7ec9-5654-4f2f-a517-ea3ce7009230",
  //         "name": "everytyre",
  //         "color_code": "#3b7ad4"
  //     },
  //     {
  //         "id": "2cf51c8b-ff1c-42e2-a05d-4d8fb821a111",
  //         "name": "terrance",
  //         "color_code": "#3b7ad4"
  //     },
  //     {
  //         "id": "d9c3e8c0-b85f-4509-8536-b93ba76581df",
  //         "name": "navidok",
  //         "color_code": "#3b7ad4"
  //     },
  //     {
  //         "id": "93149d81-07a3-4e02-8ba9-5e684053c3bc",
  //         "name": "Drops VR",
  //         "color_code": "#3b7ad4"
  //     },
  //     {
  //         "id": "ad761ea7-8c50-46a5-a162-347edcdff226",
  //         "name": "metaverse VR",
  //         "color_code": "#3b7ad4"
  //     },
  //     {
  //         "id": "49abfb76-55f2-4374-8aed-157c4c7446c5",
  //         "name": "go wall",
  //         "color_code": "#3b7ad4"
  //     },
  //     {
  //         "id": "d91d90a7-ff3e-4639-8cee-f901e7809d82",
  //         "name": "test sample",
  //         "color_code": "#3b7ad4"
  //     }
  // ]
  }

  async getProjects() {
    const team_id = this.session?.team_id;
    if (!team_id) return;
    try {
      const res = await this.homePageApi.getProjectsByTeam();
      if (res) {
        this.projects = res.body;
        console.log(res.body,'console res bdy front end')
      }
    } catch (e) {
      log_error(e);
    }
    this.cdr.markForCheck();
  }

  async getTasks(isloading: boolean) {
    if (!this.homePageService.tasksViewConfig) return;
    try {
      this.loading = isloading;
      this.homePageService.loadingTasks = true;
      let config = this.homePageService.tasksViewConfig;
      config.time_zone = this.session?.timezone_name ? this.session?.timezone_name : Intl.DateTimeFormat().resolvedOptions().timeZone;
      const res = await this.homePageApi.getMyTasks(config);
      if (res) {
        this.homePageService.tasksModel = res.body;
      }
      this.loading = false;
      this.homePageService.loadingTasks = false;
    } catch (e) {
      log_error(e);
      this.loading = false;
      this.homePageService.loadingTasks = false;
    }

    this.cdr.markForCheck();
  }

  private handleTaskSelectFromView(task: IProjectTask) {
    this.showTaskModal = false;
    setTimeout(() => {
      if (task) {
        this.openTask(task);
        this.cdr.markForCheck();
      }
    }, DRAWER_ANIMATION_INTERVAL);
    this.cdr.detectChanges();
  }

  protected openTask(task: IProjectTask) {
    this.selectedTask = task;
    if (task.project_id) this.projectService.id = task.project_id;
    this.showTaskModal = true;
    this.cdr.markForCheck();
  }

  onShowChange(show: boolean) {
    if (!show) {
      this.selectedTask = null;
    }
  }

  handleNewTaskReceived(task: IMyTask): void {
    if (!task) return;
    const receivedTask: IMyTask = {
      id: task.id,
      name: task.name,
      project_id: task.project_id,
      status: task.status,
      end_date: task.end_date,
      is_task: true,
      done: false,
      project_color: task.project_color,
      project_name: task.project_name,
      team_id: this.session?.team_id,
      status_color: task.status_color?.slice(0, -2),
      project_statuses: task.project_statuses
    }
    // change tasks count on tabs
    this.homePageService.tasksModel.total++;

    // add task to all tab
    if (this.homePageService.tasksViewConfig?.current_tab === 'All') {
      this.homePageService.tasksModel.tasks.unshift(receivedTask);
    }

    // add task to no due date tab and increase count
    if (!task.end_date) {
      this.homePageService.tasksModel.no_due_date++;
      if (this.homePageService.tasksViewConfig?.current_tab === 'NoDueDate') {
        this.homePageService.tasksModel.tasks.unshift(receivedTask);
      }
    }

    if (task.end_date) {
      const dateToCheck = new Date(task.end_date);
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      // add task to today tab and increase count
      if (dateToCheck.toDateString() === today.toDateString()) {
        this.homePageService.tasksModel.today++;
        if (this.homePageService.tasksViewConfig?.current_tab === 'Today') {
          this.homePageService.tasksModel.tasks.unshift(receivedTask);
        }
      } else if (dateToCheck > today) {
        this.homePageService.tasksModel.upcoming++;
        if (this.homePageService.tasksViewConfig?.current_tab === 'Upcoming') {
          this.homePageService.tasksModel.tasks.unshift(receivedTask);
        }
      }
    }

    this.cdr.markForCheck();
  }

  trackBy(index: number, item: IProjectViewModel) {
    return item.id;
  }

}
